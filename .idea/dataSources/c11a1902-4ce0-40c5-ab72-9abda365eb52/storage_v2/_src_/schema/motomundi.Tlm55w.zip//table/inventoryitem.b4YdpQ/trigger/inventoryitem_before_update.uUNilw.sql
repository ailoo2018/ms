create definer = root@localhost trigger inventoryitem_BEFORE_UPDATE
    before update
    on inventoryitem
    for each row
BEGIN
SET NEW.ModifiedDate = NOW();
END;

