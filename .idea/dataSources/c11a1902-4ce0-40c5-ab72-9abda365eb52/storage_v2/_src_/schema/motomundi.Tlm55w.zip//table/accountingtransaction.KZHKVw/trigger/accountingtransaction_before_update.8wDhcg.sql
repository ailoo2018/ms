create definer = root@localhost trigger accountingtransaction_BEFORE_UPDATE
    before update
    on accountingtransaction
    for each row
BEGIN
SET NEW.ModifiedDate = NOW();
END;

