create definer = root@localhost trigger productcategory_BEFORE_INSERT
    before insert
    on productcategory
    for each row
BEGIN
SET NEW.ModifiedDate = NOW();
END;

