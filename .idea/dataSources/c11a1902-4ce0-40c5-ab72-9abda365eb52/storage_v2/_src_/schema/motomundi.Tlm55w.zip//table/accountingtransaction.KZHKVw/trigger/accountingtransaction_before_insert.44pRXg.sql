create definer = root@localhost trigger accountingtransaction_BEFORE_INSERT
    before insert
    on accountingtransaction
    for each row
BEGIN
SET NEW.ModifiedDate = NOW();
END;

