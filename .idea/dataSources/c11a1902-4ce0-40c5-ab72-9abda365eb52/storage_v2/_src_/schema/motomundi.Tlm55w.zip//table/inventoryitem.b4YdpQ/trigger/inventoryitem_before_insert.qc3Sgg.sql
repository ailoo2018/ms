create definer = root@localhost trigger inventoryitem_BEFORE_INSERT
    before insert
    on inventoryitem
    for each row
BEGIN
SET NEW.ModifiedDate = NOW();
END;

