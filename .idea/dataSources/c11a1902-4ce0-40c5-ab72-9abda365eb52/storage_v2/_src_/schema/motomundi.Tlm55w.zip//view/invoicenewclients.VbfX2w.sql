create definer = motomundi@`%` view invoicenewclients as
select `i`.`ReceivedById` AS `ReceivedById`, `i`.`Id` AS `InvoiceId`, `i`.`Date` AS `Date`, `i`.`DomainId` AS `DomainId`
from (`motomundi`.`invoice` `i` left join `motomundi`.`invoice` `i2`
      on (((`i2`.`ReceivedById` = `i`.`ReceivedById`) and (`i`.`Id` < `i2`.`Id`))))
where ((`i`.`DomainId` = 1) and (`i`.`PurchaseSale` = 1) and (`i`.`Type` in (0, 1)) and
       (`i`.`ReceivedById` is not null))
group by `i`.`ReceivedById`;

