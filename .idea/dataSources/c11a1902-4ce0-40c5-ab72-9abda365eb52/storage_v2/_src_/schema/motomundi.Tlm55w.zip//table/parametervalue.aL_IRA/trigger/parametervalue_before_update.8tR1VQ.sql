create definer = root@localhost trigger parametervalue_BEFORE_UPDATE
    before update
    on parametervalue
    for each row
BEGIN
SET NEW.ModifiedDate = NOW();
END;

