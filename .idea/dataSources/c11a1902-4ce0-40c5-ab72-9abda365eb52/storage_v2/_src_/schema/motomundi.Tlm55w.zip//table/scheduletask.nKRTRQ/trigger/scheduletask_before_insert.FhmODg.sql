create definer = root@localhost trigger scheduletask_BEFORE_INSERT
    before insert
    on scheduletask
    for each row
BEGIN
SET NEW.ModifiedDate = NOW();
END;

