create definer = root@localhost trigger parametervalue_BEFORE_INSERT
    before insert
    on parametervalue
    for each row
BEGIN
SET NEW.ModifiedDate = NOW();
END;

