create definer = root@localhost trigger scheduletask_BEFORE_UPDATE
    before update
    on scheduletask
    for each row
BEGIN
SET NEW.ModifiedDate = NOW();
END;

