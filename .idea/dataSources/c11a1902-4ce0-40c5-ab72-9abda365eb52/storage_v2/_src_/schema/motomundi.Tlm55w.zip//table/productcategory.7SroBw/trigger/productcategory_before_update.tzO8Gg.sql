create definer = root@localhost trigger productcategory_BEFORE_UPDATE
    before update
    on productcategory
    for each row
BEGIN
SET NEW.ModifiedDate = NOW();
END;

