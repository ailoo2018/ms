create definer = root@localhost trigger party_BEFORE_INSERT
    before insert
    on party
    for each row
BEGIN
	declare msg varchar(128);
    
    IF EXISTS (SELECT 1 FROM Party WHERE Rut= new.Rut and DomainId = new.DomainId and Deleted = 0 and Type = new.Type and new.Rut != '66.666.666-6')
	then
		set msg = concat('PartyRutValidation: Tratando de insertar un contacto con rut ya existente. Rut: ', new.rut);
		signal sqlstate '45000' set message_text = msg;
	END If;
END;

